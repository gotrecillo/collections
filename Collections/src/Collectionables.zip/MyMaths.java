
public abstract class MyMaths {
	
	/**
	 * get a random number from 0 to max
	 * @param max
	 * @return
	 */
	public static int random(int max){
		return (int)(Math.random()*max);
	}
}
